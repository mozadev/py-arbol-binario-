from claseArbol import *

#####creando nodos
n1=TreeNode("nodo raiz")
n2=TreeNode("nodo hijo izquierdo")
n3=TreeNode("nodo hijo derecho")
n4=TreeNode("nodo nieto izquierdo")

####conectando nodos
n1.left=n2
n1.right=n3
n2.left=n4

####recorrer por la izquierda
current=n1

while current:
    print(current.element)
    current=current.left

    
