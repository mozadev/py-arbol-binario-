####clase arbol binario

class TreeNode:
    def __init__(self, e):
        self.element = e
        self.left =None # hijo izquierda
        self.right = None # hijo derecha

class BinaryTree:
    def __init__(self):
        self.root=TreeNode(None) #crea un arbol vacío
        self.size=0  #numero de nodos

    '''Devuelve True si el elemento especificado está en el árbol.
        inicializando por el root, se recorre los nodos y compara
        con elemento buscado
        True si esta en el arbol
        False si no esta en el arbol
        '''
    def search(self, e):
        current = self.root # empieza en la raiz

        while current != None:
            if e < current.element:
                current = current.left # Go left
            elif e > current.element:
                current = current.right # Go right
            else: # element matches current.element
                return True # Element is found
        return False # Element is not in the tree
 
    def insert(self, e):
        if self.root.element==None:
            self.root=TreeNode(e)
            self.size +=1
        else:
            current=self.root

            while current:
                if e<current.element:
                    padre=current #nodo padre
                    current=current.left #ir izquuierda
                else:
                    if e>current.element:
                        padre=current #nodo padre
                        current=current.right #ir derecha
                    else:
                        return False #ya existe

            #padre es la hoja para insertar
            nodo=TreeNode(e)
            if e<padre.element:
                padre.left=nodo
            else:
                padre.right=nodo
            self.size +=1

            return True
            
    # Inorder traversal from the root
    def inorder(self):
        self.inorderHelper(self.root)

    # Inorder traversal from a subtree
    def inorderHelper(self, r):
        if r != None:
            self.inorderHelper(r.left)
            print(r.element, end = " ")
            self.inorderHelper(r.right)

    def postorder(self):
        self.postorderHelper(self.root)

    def postorderHelper(self, r):
        if r != None:
            self.postorderHelper(r.left)            
            self.postorderHelper(r.right)
            print(r.element, end = " ")

    def preorder(self):
        self.preorderHelper(self.root)

    def preorderHelper(self, r):
        if r != None:
            print(r.element, end = " ")
            self.preorderHelper(r.left)            
            self.preorderHelper(r.right)

    def getSize(self):
        return self.size

    def isEmpty(self):
        if self.root is None:
            return True
        else:
            return False

    def clear(self):
        self.root=None
        self.size=0

    def path(self, e):
        ruta=[]
        if self.search(e)==False:
            return ruta
        else:
            padre=self.root
            c=0

            while c<self.size:
                ruta.append(padre.element)
                if e==padre.element:
                    c=self.size
                else:
                    if e<padre.element:
                        padre=padre.left
                        c=c+1
                    else:
                        padre=padre.right
                        c=c+1
        return ruta
            
        


























        
