####test
from claseArbolBinarioA import *
####creando arbol vacío
arbol=BinaryTree()

########################creando nodos
n1 = TreeNode(5)
n2 = TreeNode(3)
n3 = TreeNode(7)
n4 = TreeNode(1)
####conectando nodos
arbol.root=n1
arbol.root.left=n2
arbol.root.right=n3
arbol.root.left.left=n4
########busca un elemento

print(arbol.search(10))








