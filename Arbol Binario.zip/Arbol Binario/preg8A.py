####test
from claseArbolBinarioA import *
####creando arbol vacío
arbol=BinaryTree()

########insertando nodos

arbol.insert(100)
arbol.insert(88)
arbol.insert(66)
arbol.insert(77)
arbol.insert(11)
arbol.insert(0)
arbol.insert(200)
arbol.insert(150)
arbol.insert(120)
arbol.insert(160)
arbol.insert(300)
arbol.insert(350)

print("inorder: ")
arbol.inorder()

print("\npostder: ")
arbol.postorder()

print("\npreorder: ")
arbol.preorder()

print("\nruta: 350")
print(arbol.path(350))
