from claseArbol import *

###creando arbol
arbol=BinaryTree()

'''####creando nodos
n1=TreeNode(5)
n2=TreeNode(3)
n3=TreeNode(7)
n4=TreeNode(1)

####conectando nodos
arbol.root=n1
arbol.root.left=n2
arbol.root.right=n3
arbol.root.left.left=n4'''

###insertando nodos

arbol.insert(5)
arbol.insert(3)
arbol.insert(7)
arbol.insert(1)

#####recorrer
current=arbol.root
while current:
    print(current.element)
    current=current.left


