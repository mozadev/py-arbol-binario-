class TreeNode:
    def __init__(self, e):
        self.element = e
        self.left = None # left child
        self.right = None # right child

class BinaryTree:
    def __init__(self):
        self.root=TreeNode(None) #crea un arbol vacío
        self.size=0

    def search(self, e):
        current = self.root # Start from the root

        while current != None:
            if e < current.element:
                current = current.left # Go left
            elif e > current.element:
                current = current.right # Go right
            else: # element matches current.element
                return True # Element is found

        return False # Element is not in the tree

    def insert(self, e):
        if self.root.element==None:
            self.root=TreeNode(e)
            self.size +=1
        else:    
            current = self.root 

            while current:
                if e < current.element:
                    padre=current
                    current = current.left # Go left
                elif e > current.element:
                    padre=current
                    current = current.right # Go right
                else: 
                    return False #ya existe

            #padre es la hoja para insertar
            nodo=TreeNode(e)
            if e<padre.element:
                padre.left=nodo
            else:
                padre.right=nodo
            self.size +=1

            return True
















    











    
    
