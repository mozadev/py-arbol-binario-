####test
from claseArbolA import *
########################creando nodos
n1 = TreeNode("nodo raiz")
n2 = TreeNode("nodo hijo izquierdo")
n3 = TreeNode("nodo hijo derecho")
n4 = TreeNode("nodo nieto iquierdo")

####conectando nodos
n1.left=n2
n1.right=n3
n2.left=n4

########recorrer por la izquierda

current=n1
while current:
    print(current.element)
    current=current.left

'''
n1.element
'nodo raiz'
n1.left.element
'nodo hijo izquierdo'
n1.right.element
'nodo hijo derecho'
n2.left.element
'nodo nieto iquierdo'
n1.left.left.element
'nodo nieto iquierdo'
'''



